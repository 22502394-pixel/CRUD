﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace akai_2
{
    internal class Conexao
    {
        private string stringConexao = "Server=localhost;Database=DB_Delivery;Uid=root;Pwd=;";
        public MySqlConnection conectar;

        public Conexao()
        {
            conectar = new MySqlConnection(stringConexao);
        }

        public void Abrir()
        {
            if (conectar.State == ConnectionState.Closed)
                conectar.Open();
        }

        public void Fechar()
        {
            if (conectar.State == ConnectionState.Open)
                conectar.Close();
        }
    }
}



