﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace akai_2
{
    public partial class Form1Login : Form
    {
        public Form1Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtEmail.Text) || string.IsNullOrWhiteSpace(txtSenha.Text))
            {
                MessageBox.Show("Preencha o usuário/e-mail e a senha.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Conexao bd = new Conexao();
            try
            {
                bd.Abrir();
                string query = "SELECT tipo FROM usuarios WHERE email = @email AND senha = @senha LIMIT 1";
                MySqlCommand cmd = new MySqlCommand(query, bd.conectar);
                cmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim());
                cmd.Parameters.AddWithValue("@senha", txtSenha.Text.Trim());

                object resultado = cmd.ExecuteScalar();

                if (resultado != null)
                {
                    string tipoUsuario = resultado.ToString().Trim().ToUpper();
                    this.Hide();

                    if (tipoUsuario == "ADMIN")
                    {
                        FrmPrincipal principal = new FrmPrincipal();
                        principal.ShowDialog();
                    }
                    else if (tipoUsuario == "CLIENTE")
                    {
                        Cliente telaCliente = new Cliente();
                        telaCliente.ShowDialog();
                    }
                    else if (tipoUsuario == "ENTREGADOR")
                    {
                        Entregador telaEntregador = new Entregador();
                        telaEntregador.ShowDialog();
                    }
                    else
                    {
                        FrmPrincipal principal = new FrmPrincipal();
                        principal.ShowDialog();
                    }

                    this.Close();
                }
                else
                {
                    MessageBox.Show("Usuário ou senha incorretos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message, "Erro Crítico", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.Fechar();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }
    }
}
