﻿using System;
using System.Windows.Forms;

namespace akai_2
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();

            btnPedidos.Click += btnPedidos_Click;
            btnProdutos.Click += btnProdutos_Click;
            btnClientes.Click += btnClientes_Click;
            btnEntregadores.Click += btnEntregadores_Click;
            btnSair.Click += btnSair_Click;
        }

        private void btnPedidos_Click(object sender, EventArgs e)
        {
            Form1 telaPedidos = new Form1();
            telaPedidos.ShowDialog();
        }

        private void btnProdutos_Click(object sender, EventArgs e)
        {
            Produtos telaProdutos = new Produtos();
            telaProdutos.ShowDialog();
        }

        private void btnClientes_Click(object sender, EventArgs e)
        {
            Cliente telaClientes = new Cliente();
            telaClientes.ShowDialog();
        }

        private void btnEntregadores_Click(object sender, EventArgs e)
        {
            Entregador telaEntregadores = new Entregador();
            telaEntregadores.ShowDialog();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
