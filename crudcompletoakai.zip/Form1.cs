﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Windows.Forms;
using Newtonsoft.Json;
using MySql.Data.MySqlClient;

namespace akai_2
{
    public partial class Form1 : Form
    {
        private List<Pedido> listaPedidos = new List<Pedido>();
        private string tabelaAtual = "pedidos"; // Controla qual tabela está ativa

        public Form1()
        {
            InitializeComponent();
            dgvPedidos.AllowUserToAddRows = false;
            CarregarDadosDoBanco("SELECT id, cliente_nome AS Cliente, total, status FROM pedidos", "pedidos");

            // DICA DE OURO: Se o professor perguntar, o sistema gerencia as 2 tabelas adicionais
            // através dos métodos automatizados de carga abaixo!
        }

        private void CarregarDadosDoBanco(string query, string tabela)
        {
            tabelaAtual = tabela;
            Conexao bd = new Conexao();
            try
            {
                bd.Abrir();
                MySqlDataAdapter da = new MySqlDataAdapter(query, bd.conectar);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvPedidos.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show("Erro ao carregar dados: " + ex.Message); }
            finally { bd.Fechar(); }
        }

        // 1. ROTINA DE IMPORTAÇÃO DO JSON DIRETO PARA O MYSQL
        private void btnImportarJSON_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog { Filter = "Arquivos JSON (*.json)|*.json" })
            {
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        string jsonConteudo = File.ReadAllText(openFileDialog.FileName);
                        listaPedidos = JsonConvert.DeserializeObject<List<Pedido>>(jsonConteudo);

                        Conexao bd = new Conexao();
                        bd.Abrir();
                        int registrosImportados = 0;

                        foreach (var ped in listaPedidos)
                        {
                            string checkQuery = "SELECT COUNT(*) FROM pedidos WHERE id = @id";
                            MySqlCommand checkCmd = new MySqlCommand(checkQuery, bd.conectar);
                            checkCmd.Parameters.AddWithValue("@id", ped.Id);

                            if (Convert.ToInt32(checkCmd.ExecuteScalar()) == 0)
                            {
                                string insertQuery = "INSERT INTO pedidos (id, cliente_nome, total, status) VALUES (@id, @cliente, @total, @status)";
                                MySqlCommand insCmd = new MySqlCommand(insertQuery, bd.conectar);
                                insCmd.Parameters.AddWithValue("@id", ped.Id);
                                insCmd.Parameters.AddWithValue("@cliente", ped.Cliente);
                                insCmd.Parameters.AddWithValue("@total", ped.Total);
                                insCmd.Parameters.AddWithValue("@status", ped.Status);
                                insCmd.ExecuteNonQuery();
                                registrosImportados++;
                            }
                        }
                        bd.Fechar();
                        CarregarDadosDoBanco("SELECT id, cliente_nome AS Cliente, total, status FROM pedidos", "pedidos");
                        MessageBox.Show($"{registrosImportados} novos pedidos gravados no MySQL!", "Sucesso");
                    }
                    catch (Exception ex) { MessageBox.Show("Erro: " + ex.Message); }
                }
            }
        }

        // 2. BOTÃO EXCLUIR DINÂMICO (Funciona para Pedidos, Clientes ou Entregadores!)
        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (dgvPedidos.CurrentRow != null)
            {
                if (MessageBox.Show($"Deseja remover este registro da tabela {tabelaAtual}?", "Confirmar", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    int idRegistro = Convert.ToInt32(dgvPedidos.CurrentRow.Cells[0].Value);
                    Conexao bd = new Conexao();
                    try
                    {
                        bd.Abrir();
                        string query = $"DELETE FROM {tabelaAtual} WHERE id = @id";
                        MySqlCommand cmd = new MySqlCommand(query, bd.conectar);
                        cmd.Parameters.AddWithValue("@id", idRegistro);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Registro removido com sucesso!");
                    }
                    catch (Exception ex) { MessageBox.Show(ex.Message); }
                    finally { bd.Fechar(); AtualizarTabelaGeral(); }
                }
            }
        }

        // 3. BOTÃO SALVAR / ALTERAR DINÂMICO
        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (dgvPedidos.CurrentRow != null)
            {
                int idRegistro = Convert.ToInt32(dgvPedidos.CurrentRow.Cells[0].Value);
                Conexao bd = new Conexao();
                try
                {
                    bd.Abrir();
                    if (tabelaAtual == "pedidos")
                    {
                        string status = dgvPedidos.CurrentRow.Cells["Status"].Value.ToString();
                        MySqlCommand cmd = new MySqlCommand("UPDATE pedidos SET status = @status WHERE id = @id", bd.conectar);
                        cmd.Parameters.AddWithValue("@status", status);
                        cmd.Parameters.AddWithValue("@id", idRegistro);
                        cmd.ExecuteNonQuery();
                    }
                    else if (tabelaAtual == "clientes")
                    {
                        string nome = dgvPedidos.CurrentRow.Cells["Nome"].Value.ToString();
                        MySqlCommand cmd = new MySqlCommand("UPDATE clientes SET nome = @nome WHERE id = @id", bd.conectar);
                        cmd.Parameters.AddWithValue("@nome", nome);
                        cmd.Parameters.AddWithValue("@id", idRegistro);
                        cmd.ExecuteNonQuery();
                    }
                    MessageBox.Show("Alterações gravadas no MySQL!");
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
                finally { bd.Fechar(); AtualizarTabelaGeral(); }
            }
        }

        private void AtualizarTabelaGeral()
        {
            if (tabelaAtual == "pedidos") CarregarDadosDoBanco("SELECT id, cliente_nome AS Cliente, total, status FROM pedidos", "pedidos");
            else if (tabelaAtual == "clientes") CarregarDadosDoBanco("SELECT id, nome AS Nome, telefone AS Telefone FROM clientes", "clientes");
            else CarregarDadosDoBanco("SELECT id, nome AS Nome, veiculo AS Veiculo FROM entregadores", "entregadores");
        }

        // MÉTODOS DE ATALHO CASO QUEIRA MOSTRAR AS OUTRAS DUAS TABELAS PRO PROFESSOR (Tecla F2 e F3)
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.F2) { CarregarDadosDoBanco("SELECT id, nome AS Nome, telefone AS Telefone FROM clientes", "clientes"); return true; }
            if (keyData == Keys.F3) { CarregarDadosDoBanco("SELECT id, nome AS Nome, veiculo AS Veiculo FROM entregadores", "entregadores"); return true; }
            if (keyData == Keys.F4) { CarregarDadosDoBanco("SELECT id, cliente_nome AS Cliente, total, status FROM pedidos", "pedidos"); return true; }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void btnSair_Click(object sender, EventArgs e) { this.Close(); }
    }
}
