﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace akai_2
{
    public partial class Cliente : Form
    {
        public Cliente()
        {
            InitializeComponent();

            btnCadastrar.Click -= btnCadastrar_Click;
            btnCadastrar.Click -= btnCadastrar_Click_1;
            btnAlterar.Click -= btnAlterar_Click;
            btnAlterar.Click -= btnAlterar_Click_1;
            btnExcluir.Click -= btnExcluir_Click;
            btnExcluir.Click -= btnExcluir_Click_1;

            ConfigurarBotao(btnCadastrar);
            ConfigurarBotao(btnAlterar);
            ConfigurarBotao(btnExcluir);

            dgvClientes.CellClick -= dgvClientes_CellClick;
            dgvClientes.CellClick += dgvClientes_CellClick;

            txtId.ReadOnly = true;
            ListarClientes();
        }

        private void ConfigurarBotao(Button botao)
        {
            string texto = botao.Text.Trim().ToUpper();
            if (texto == "CADASTRAR") botao.Click += btnCadastrar_Click;
            else if (texto == "ALTERAR") botao.Click += btnAlterar_Click;
            else if (texto == "EXCLUIR") botao.Click += btnExcluir_Click;
        }

        private void ListarClientes()
        {
            Conexao bd = new Conexao();
            try
            {
                bd.Abrir();
                string query = @"SELECT c.id, c.nome, c.telefone, u.senha 
                                 FROM clientes c 
                                 LEFT JOIN usuarios u ON u.email = c.nome AND u.tipo = 'CLIENTE'";
                MySqlDataAdapter da = new MySqlDataAdapter(query, bd.conectar);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvClientes.DataSource = dt;
                dgvClientes.AllowUserToAddRows = false;
                dgvClientes.ReadOnly = true;
                dgvClientes.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao listar clientes: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.Fechar();
            }
        }

        private void LimparCampos()
        {
            txtId.Clear();
            txtNome.Clear();
            txtTelefone.Clear();
            txtSenha.Clear();
            txtNome.Focus();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNome.Text) || string.IsNullOrWhiteSpace(txtSenha.Text))
            {
                MessageBox.Show("Digite o nome e a senha do cliente para cadastrar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Conexao bd = new Conexao();
            try
            {
                bd.Abrir();

                // 1. Salva na tabela clientes
                string queryCliente = "INSERT INTO clientes (nome, telefone) VALUES (@nome, @telefone)";
                MySqlCommand cmdCliente = new MySqlCommand(queryCliente, bd.conectar);
                cmdCliente.Parameters.AddWithValue("@nome", txtNome.Text.Trim());
                cmdCliente.Parameters.AddWithValue("@telefone", txtTelefone.Text.Trim());
                cmdCliente.ExecuteNonQuery();

                // 2. Cria o login automaticamente na tabela usuarios
                string queryUsuario = @"INSERT INTO usuarios (email, senha, tipo) 
                                        VALUES (@email, @senha, 'CLIENTE')
                                        ON DUPLICATE KEY UPDATE senha = @senha, tipo = 'CLIENTE'";
                MySqlCommand cmdUser = new MySqlCommand(queryUsuario, bd.conectar);
                cmdUser.Parameters.AddWithValue("@email", txtNome.Text.Trim());
                cmdUser.Parameters.AddWithValue("@senha", txtSenha.Text.Trim());
                cmdUser.ExecuteNonQuery();

                MessageBox.Show("Cliente e login cadastrados com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimparCampos();
                ListarClientes();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao cadastrar cliente: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.Fechar();
            }
        }

        private void dgvClientes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow linha = dgvClientes.Rows[e.RowIndex];
                txtId.Text = linha.Cells["id"].Value?.ToString() ?? "";
                txtNome.Text = linha.Cells["nome"].Value?.ToString() ?? "";
                txtTelefone.Text = linha.Cells["telefone"].Value?.ToString() ?? "";
                txtSenha.Text = linha.Cells["senha"].Value?.ToString() ?? "";
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtId.Text))
            {
                MessageBox.Show("Clique em um cliente na tabela antes de alterar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtNome.Text) || string.IsNullOrWhiteSpace(txtSenha.Text))
            {
                MessageBox.Show("O nome e a senha não podem ficar vazios.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Conexao bd = new Conexao();
            try
            {
                bd.Abrir();

                string query = "UPDATE clientes SET nome = @nome, telefone = @telefone WHERE id = @id";
                MySqlCommand cmd = new MySqlCommand(query, bd.conectar);
                cmd.Parameters.AddWithValue("@nome", txtNome.Text.Trim());
                cmd.Parameters.AddWithValue("@telefone", txtTelefone.Text.Trim());
                cmd.Parameters.AddWithValue("@id", Convert.ToInt32(txtId.Text));
                cmd.ExecuteNonQuery();

                string queryUser = @"INSERT INTO usuarios (email, senha, tipo) 
                                     VALUES (@email, @senha, 'CLIENTE')
                                     ON DUPLICATE KEY UPDATE senha = @senha, tipo = 'CLIENTE'";
                MySqlCommand cmdUser = new MySqlCommand(queryUser, bd.conectar);
                cmdUser.Parameters.AddWithValue("@email", txtNome.Text.Trim());
                cmdUser.Parameters.AddWithValue("@senha", txtSenha.Text.Trim());
                cmdUser.ExecuteNonQuery();

                MessageBox.Show("Cliente atualizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimparCampos();
                ListarClientes();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao alterar cliente: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.Fechar();
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtId.Text))
            {
                MessageBox.Show("Clique em um cliente na tabela antes de excluir.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult confirmacao = MessageBox.Show($"Deseja realmente excluir o cliente #{txtId.Text} ({txtNome.Text})?", "Confirmar Exclusão", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirmacao == DialogResult.Yes)
            {
                Conexao bd = new Conexao();
                try
                {
                    bd.Abrir();

                    string query = "DELETE FROM clientes WHERE id = @id";
                    MySqlCommand cmd = new MySqlCommand(query, bd.conectar);
                    cmd.Parameters.AddWithValue("@id", Convert.ToInt32(txtId.Text));
                    cmd.ExecuteNonQuery();

                    string queryUser = "DELETE FROM usuarios WHERE email = @email AND tipo = 'CLIENTE'";
                    MySqlCommand cmdUser = new MySqlCommand(queryUser, bd.conectar);
                    cmdUser.Parameters.AddWithValue("@email", txtNome.Text.Trim());
                    cmdUser.ExecuteNonQuery();

                    MessageBox.Show("Cliente excluído com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LimparCampos();
                    ListarClientes();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao excluir cliente: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    bd.Fechar();
                }
            }
        }

        private void btnCadastrar_Click_1(object sender, EventArgs e) { }
        private void btnAlterar_Click_1(object sender, EventArgs e) { }
        private void btnExcluir_Click_1(object sender, EventArgs e) { }
        private void dgvClientes_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void textBox2_TextChanged(object sender, EventArgs e) { }
        private void Cliente_Load(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void txtId_TextChanged(object sender, EventArgs e) { }

        private void txtSenha_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
