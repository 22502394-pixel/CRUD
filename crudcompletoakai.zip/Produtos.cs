﻿using System;
using System.Data;
using System.Globalization;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace akai_2
{
    public partial class Produtos : Form
    {
        public Produtos()
        {
            InitializeComponent();

            // Conecta os botões e a grade direto pelo código
            btnAlterar.Click += btnAlterar_Click;
            btnExcluir.Click += btnExcluir_Click;
            dgvProdutos.CellClick += dgvProdutos_CellClick;

            txtId.ReadOnly = true;
            ListarProdutos();
        }

        // 1. LISTAR PRODUTOS (READ)
        private void ListarProdutos()
        {
            Conexao bd = new Conexao();
            try
            {
                bd.Abrir();
                string query = "SELECT id, nome, preco FROM produtos";
                MySqlDataAdapter da = new MySqlDataAdapter(query, bd.conectar);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvProdutos.DataSource = dt;
                dgvProdutos.AllowUserToAddRows = false; // Garante que nenhum produto novo seja adicionado na grade
                dgvProdutos.ReadOnly = true;
                dgvProdutos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao listar produtos: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.Fechar();
            }
        }

        private void LimparCampos()
        {
            txtId.Clear();
            txtNome.Clear();
            txtPreco.Clear();
        }

        // PREENCHE OS CAMPOS AO CLICAR NA TABELA
        private void dgvProdutos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow linha = dgvProdutos.Rows[e.RowIndex];
                txtId.Text = linha.Cells["id"].Value.ToString();
                txtNome.Text = linha.Cells["nome"].Value.ToString();
                txtPreco.Text = linha.Cells["preco"].Value.ToString();
            }
        }

        // 2. ALTERAR PRODUTO (UPDATE)
        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtId.Text))
            {
                MessageBox.Show("Clique em um produto na tabela antes de alterar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Conexao bd = new Conexao();
            try
            {
                // Aceita tanto vírgula quanto ponto no preço (ex: 53,90 ou 53.90)
                decimal precoConvertido = Convert.ToDecimal(txtPreco.Text.Replace(".", ","), new CultureInfo("pt-BR"));

                bd.Abrir();
                string query = "UPDATE produtos SET nome = @nome, preco = @preco WHERE id = @id";
                MySqlCommand cmd = new MySqlCommand(query, bd.conectar);
                cmd.Parameters.AddWithValue("@nome", txtNome.Text);
                cmd.Parameters.AddWithValue("@preco", precoConvertido);
                cmd.Parameters.AddWithValue("@id", Convert.ToInt32(txtId.Text));
                cmd.ExecuteNonQuery();

                MessageBox.Show("Produto atualizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimparCampos();
                ListarProdutos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao alterar produto: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.Fechar();
            }
        }

        // 3. EXCLUIR PRODUTO (DELETE)
        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtId.Text))
            {
                MessageBox.Show("Clique em um produto na tabela antes de excluir.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult confirmacao = MessageBox.Show($"Deseja excluir o produto #{txtId.Text} ({txtNome.Text})?", "Confirmar Exclusão", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirmacao == DialogResult.Yes)
            {
                Conexao bd = new Conexao();
                try
                {
                    bd.Abrir();
                    string query = "DELETE FROM produtos WHERE id = @id";
                    MySqlCommand cmd = new MySqlCommand(query, bd.conectar);
                    cmd.Parameters.AddWithValue("@id", Convert.ToInt32(txtId.Text));
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Produto excluído com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LimparCampos();
                    ListarProdutos();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao excluir produto: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    bd.Fechar();
                }
            }
        }
    }
}
