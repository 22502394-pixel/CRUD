﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace akai_2
{
    public partial class Entregador : Form
    {
        public Entregador()
        {
            InitializeComponent();

            btnCadastrar.Click -= btnCadastrar_Click;
            btnCadastrar.Click += btnCadastrar_Click;

            btnAlterar.Click -= btnAlterar_Click;
            btnAlterar.Click += btnAlterar_Click;

            btnExcluir.Click -= btnExcluir_Click;
            btnExcluir.Click += btnExcluir_Click;

            dgvEntregadores.CellClick -= dgvEntregadores_CellClick;
            dgvEntregadores.CellClick += dgvEntregadores_CellClick;

            txtId.ReadOnly = true;
            ListarEntregadores();
        }

        private void ListarEntregadores()
        {
            Conexao bd = new Conexao();
            try
            {
                bd.Abrir();
                string query = @"SELECT e.id, e.nome, e.veiculo, u.senha 
                                 FROM entregadores e 
                                 LEFT JOIN usuarios u ON u.email = e.nome AND u.tipo = 'ENTREGADOR'";
                MySqlDataAdapter da = new MySqlDataAdapter(query, bd.conectar);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvEntregadores.DataSource = dt;
                dgvEntregadores.AllowUserToAddRows = false;
                dgvEntregadores.ReadOnly = true;
                dgvEntregadores.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao listar entregadores: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.Fechar();
            }
        }

        private void LimparCampos()
        {
            txtId.Clear();
            txtNome.Clear();
            txtVeiculo.Clear();
            txtSenha.Clear();
            txtNome.Focus();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNome.Text) || string.IsNullOrWhiteSpace(txtSenha.Text))
            {
                MessageBox.Show("Digite o nome e a senha do entregador.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Conexao bd = new Conexao();
            try
            {
                bd.Abrir();

                // 1. Salva na tabela entregadores
                string query = "INSERT INTO entregadores (nome, veiculo) VALUES (@nome, @veiculo)";
                MySqlCommand cmd = new MySqlCommand(query, bd.conectar);
                cmd.Parameters.AddWithValue("@nome", txtNome.Text.Trim());
                cmd.Parameters.AddWithValue("@veiculo", txtVeiculo.Text.Trim());
                cmd.ExecuteNonQuery();

                // 2. Cria o login automaticamente na tabela usuarios
                string queryUser = @"INSERT INTO usuarios (email, senha, tipo) 
                                     VALUES (@email, @senha, 'ENTREGADOR')
                                     ON DUPLICATE KEY UPDATE senha = @senha, tipo = 'ENTREGADOR'";
                MySqlCommand cmdUser = new MySqlCommand(queryUser, bd.conectar);
                cmdUser.Parameters.AddWithValue("@email", txtNome.Text.Trim());
                cmdUser.Parameters.AddWithValue("@senha", txtSenha.Text.Trim());
                cmdUser.ExecuteNonQuery();

                MessageBox.Show("Entregador e login cadastrados com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimparCampos();
                ListarEntregadores();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao cadastrar: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.Fechar();
            }
        }

        private void dgvEntregadores_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow linha = dgvEntregadores.Rows[e.RowIndex];
                txtId.Text = linha.Cells["id"].Value?.ToString() ?? "";
                txtNome.Text = linha.Cells["nome"].Value?.ToString() ?? "";
                txtVeiculo.Text = linha.Cells["veiculo"].Value?.ToString() ?? "";
                txtSenha.Text = linha.Cells["senha"].Value?.ToString() ?? "";
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtId.Text))
            {
                MessageBox.Show("Clique em um entregador na tabela antes de alterar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtNome.Text) || string.IsNullOrWhiteSpace(txtSenha.Text))
            {
                MessageBox.Show("O nome e a senha não podem ficar vazios.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Conexao bd = new Conexao();
            try
            {
                bd.Abrir();

                string query = "UPDATE entregadores SET nome = @nome, veiculo = @veiculo WHERE id = @id";
                MySqlCommand cmd = new MySqlCommand(query, bd.conectar);
                cmd.Parameters.AddWithValue("@nome", txtNome.Text.Trim());
                cmd.Parameters.AddWithValue("@veiculo", txtVeiculo.Text.Trim());
                cmd.Parameters.AddWithValue("@id", Convert.ToInt32(txtId.Text));
                cmd.ExecuteNonQuery();

                string queryUser = @"INSERT INTO usuarios (email, senha, tipo) 
                                     VALUES (@email, @senha, 'ENTREGADOR')
                                     ON DUPLICATE KEY UPDATE senha = @senha, tipo = 'ENTREGADOR'";
                MySqlCommand cmdUser = new MySqlCommand(queryUser, bd.conectar);
                cmdUser.Parameters.AddWithValue("@email", txtNome.Text.Trim());
                cmdUser.Parameters.AddWithValue("@senha", txtSenha.Text.Trim());
                cmdUser.ExecuteNonQuery();

                MessageBox.Show("Entregador atualizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimparCampos();
                ListarEntregadores();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao alterar: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.Fechar();
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtId.Text))
            {
                MessageBox.Show("Clique em um entregador na tabela antes de excluir.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult confirmacao = MessageBox.Show($"Deseja excluir o entregador #{txtId.Text} ({txtNome.Text})?", "Confirmar Exclusão", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirmacao == DialogResult.Yes)
            {
                Conexao bd = new Conexao();
                try
                {
                    bd.Abrir();

                    string query = "DELETE FROM entregadores WHERE id = @id";
                    MySqlCommand cmd = new MySqlCommand(query, bd.conectar);
                    cmd.Parameters.AddWithValue("@id", Convert.ToInt32(txtId.Text));
                    cmd.ExecuteNonQuery();

                    string queryUser = "DELETE FROM usuarios WHERE email = @email AND tipo = 'ENTREGADOR'";
                    MySqlCommand cmdUser = new MySqlCommand(queryUser, bd.conectar);
                    cmdUser.Parameters.AddWithValue("@email", txtNome.Text.Trim());
                    cmdUser.ExecuteNonQuery();

                    MessageBox.Show("Entregador excluído com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LimparCampos();
                    ListarEntregadores();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao excluir: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    bd.Fechar();
                }
            }
        }

        private void txtSenha_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
